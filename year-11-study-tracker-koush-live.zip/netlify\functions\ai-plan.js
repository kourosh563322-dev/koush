const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
const DEFAULT_MODEL = "openai/gpt-oss-20b";

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return jsonResponse(405, { error: "Use POST for AI study plans." });
  }

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    return jsonResponse(500, { error: "GROQ_API_KEY is not set." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (error) {
    return jsonResponse(400, { error: "Invalid JSON body." });
  }

  const plan = normaliseIncomingPlan(body.plan);
  if (!plan) {
    return jsonResponse(400, { error: "Missing plan details." });
  }

  try {
    const response = await fetch(GROQ_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL || DEFAULT_MODEL,
        messages: [
          {
            role: "system",
            content: "You are an expert Australian Year 11 study coach. Build realistic ATAR-focused daily study plans. Return only valid JSON, with no markdown."
          },
          {
            role: "user",
            content: buildPrompt(plan)
          }
        ],
        temperature: 0.35,
        max_tokens: 1800
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return jsonResponse(response.status, {
        error: data.error?.message || "Groq request failed."
      });
    }

    const text = extractResponseText(data);
    const aiPlan = parseJsonFromText(text);

    return jsonResponse(200, { plan: aiPlan });
  } catch (error) {
    return jsonResponse(500, { error: "Could not generate an AI plan." });
  }
};

function buildPrompt(plan) {
  return JSON.stringify({
    instruction: "Create a smart daily study plan for this student. Use the exact total minutes as a hard limit. Choose what to study, split time realistically, and write useful practice questions. Do not invent syllabus facts that are too specific; write questions the student can answer from class notes.",
    requiredJsonShape: {
      summary: "One short sentence explaining the plan.",
      totalMinutes: "number",
      selectedTopics: [{ title: "topic name" }],
      focusPoints: ["3-5 clear priorities for today"],
      blocks: [
        {
          title: "block title",
          topic: "topic or All topics",
          mode: "Learn, Revise, Practice, Recall, or Review",
          minutes: "number",
          actions: ["2-4 exact actions"]
        }
      ],
      questions: [
        {
          topic: "topic name",
          questions: ["5-7 practice questions, from easy to harder"]
        }
      ]
    },
    studentContext: {
      yearLevel: "Year 11",
      country: "Australia",
      goal: "99+ ATAR",
      subject: plan.subject,
      planName: plan.name,
      goalDate: plan.deadline,
      availableMinutesToday: plan.minutes,
      confidenceFrom1To5: plan.confidence,
      focusMode: plan.focus,
      topics: plan.topics
    }
  });
}

function normaliseIncomingPlan(plan) {
  if (!plan || typeof plan !== "object") {
    return null;
  }

  const topics = Array.isArray(plan.topics)
    ? plan.topics.map((topic) => String(topic).trim()).filter(Boolean).slice(0, 20)
    : [];

  if (!plan.name || !plan.subject || !plan.deadline || !topics.length) {
    return null;
  }

  return {
    name: String(plan.name).trim(),
    subject: String(plan.subject).trim(),
    deadline: String(plan.deadline).trim(),
    minutes: Math.max(20, Number(plan.minutes) || 120),
    confidence: Math.min(5, Math.max(1, Number(plan.confidence) || 3)),
    focus: ["mixed", "learn", "revise", "practice"].includes(plan.focus) ? plan.focus : "mixed",
    topics
  };
}

function extractResponseText(data) {
  return data.choices?.[0]?.message?.content || "";
}

function parseJsonFromText(text) {
  const trimmed = String(text || "").trim();
  if (!trimmed) {
    throw new Error("Empty AI response.");
  }

  try {
    return JSON.parse(trimmed);
  } catch (error) {
    const match = trimmed.match(/\{[\s\S]*\}/);
    if (!match) {
      throw error;
    }
    return JSON.parse(match[0]);
  }
}

function jsonResponse(statusCode, data) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store"
    },
    body: JSON.stringify(data)
  };
}
