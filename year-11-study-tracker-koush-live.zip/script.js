const storageKey = "year11-study-tracker-v1";
const settingsKey = "year11-study-tracker-settings-v1";
const topicPlansKey = "year11-topic-plans-v1";
const koushChatKey = "year11-koush-chat-v1";

const priorityWeight = {
  Low: 1,
  Medium: 2,
  High: 3
};

let tasks = loadTasks();
let topicPlans = loadTopicPlans();
let koushMessages = loadKoushMessages();
let settings = loadSettings();

const elements = {
  dailyLimit: document.querySelector("#dailyLimit"),
  topicPlannerForm: document.querySelector("#topicPlannerForm"),
  plannerId: document.querySelector("#plannerId"),
  plannerName: document.querySelector("#plannerName"),
  plannerSubject: document.querySelector("#plannerSubject"),
  plannerDeadline: document.querySelector("#plannerDeadline"),
  plannerMinutes: document.querySelector("#plannerMinutes"),
  plannerConfidence: document.querySelector("#plannerConfidence"),
  plannerFocus: document.querySelector("#plannerFocus"),
  plannerTopics: document.querySelector("#plannerTopics"),
  generatePlan: document.querySelector("#generatePlan"),
  generateAiPlan: document.querySelector("#generateAiPlan"),
  aiPlanStatus: document.querySelector("#aiPlanStatus"),
  smartPlanSummary: document.querySelector("#smartPlanSummary"),
  smartPlan: document.querySelector("#smartPlan"),
  savedTopicPlans: document.querySelector("#savedTopicPlans"),
  koushForm: document.querySelector("#koushForm"),
  koushQuestion: document.querySelector("#koushQuestion"),
  askKoushButton: document.querySelector("#askKoushButton"),
  clearKoushChat: document.querySelector("#clearKoushChat"),
  koushChat: document.querySelector("#koushChat"),
  koushStatus: document.querySelector("#koushStatus"),
  taskForm: document.querySelector("#taskForm"),
  taskId: document.querySelector("#taskId"),
  taskName: document.querySelector("#taskName"),
  subject: document.querySelector("#subject"),
  deadline: document.querySelector("#deadline"),
  difficulty: document.querySelector("#difficulty"),
  estimatedTime: document.querySelector("#estimatedTime"),
  priority: document.querySelector("#priority"),
  notes: document.querySelector("#notes"),
  submitTask: document.querySelector("#submitTask"),
  cancelEdit: document.querySelector("#cancelEdit"),
  formTitle: document.querySelector("#formTitle"),
  subjectFilter: document.querySelector("#subjectFilter"),
  sortBy: document.querySelector("#sortBy"),
  taskList: document.querySelector("#taskList"),
  todayPlan: document.querySelector("#todayPlan"),
  planSummary: document.querySelector("#planSummary"),
  subjectOptions: document.querySelector("#subjectOptions"),
  backupStatus: document.querySelector("#backupStatus"),
  exportJson: document.querySelector("#exportJson"),
  importJson: document.querySelector("#importJson"),
  statIncomplete: document.querySelector("#statIncomplete"),
  statWeek: document.querySelector("#statWeek"),
  statTime: document.querySelector("#statTime"),
  statCompleted: document.querySelector("#statCompleted")
};

elements.dailyLimit.value = settings.dailyLimit;
elements.plannerMinutes.value = settings.dailyLimit;
render();

elements.dailyLimit.addEventListener("input", () => {
  const value = Math.max(15, Number(elements.dailyLimit.value) || 180);
  settings.dailyLimit = value;
  saveSettings();
  renderTodayPlan();
});

elements.topicPlannerForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const plan = readPlannerForm();
  if (!plan) {
    return;
  }

  topicPlans = [plan, ...topicPlans.filter((item) => item.id !== plan.id)];
  settings.activeTopicPlanId = plan.id;
  saveTopicPlans();
  saveSettings();
  setAiPlanStatus("Quick plan generated. Use AI when the site is deployed online.");
  resetPlannerForm();
  render();
});

elements.generateAiPlan.addEventListener("click", generateAiStudyPlan);

elements.koushForm.addEventListener("submit", askKoush);
elements.clearKoushChat.addEventListener("click", () => {
  koushMessages = [];
  saveKoushMessages();
  renderKoushChat();
  setKoushStatus("");
});

elements.taskForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const formTask = {
    id: elements.taskId.value || crypto.randomUUID(),
    name: elements.taskName.value.trim(),
    subject: elements.subject.value.trim(),
    deadline: elements.deadline.value,
    difficulty: Number(elements.difficulty.value),
    estimatedTime: Number(elements.estimatedTime.value),
    priority: elements.priority.value,
    notes: elements.notes.value.trim(),
    complete: false,
    createdAt: new Date().toISOString()
  };

  if (!formTask.name || !formTask.subject || !formTask.deadline) {
    return;
  }

  const existing = tasks.find((task) => task.id === formTask.id);
  if (existing) {
    formTask.complete = existing.complete;
    formTask.createdAt = existing.createdAt;
    tasks = tasks.map((task) => task.id === formTask.id ? formTask : task);
  } else {
    tasks.push(formTask);
  }

  saveTasks();
  resetForm();
  render();
});

elements.cancelEdit.addEventListener("click", resetForm);
elements.subjectFilter.addEventListener("change", renderTasks);
elements.sortBy.addEventListener("change", renderTasks);

elements.exportJson.addEventListener("click", () => {
  const payload = JSON.stringify({ tasks, topicPlans, koushMessages, settings, exportedAt: new Date().toISOString() }, null, 2);
  const blob = new Blob([payload], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `year-11-study-tracker-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
  setBackupStatus("Backup exported.");
});

elements.importJson.addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) {
    return;
  }

  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const importedTasks = Array.isArray(data) ? data : data.tasks;
    const importedTopicPlans = Array.isArray(data.topicPlans) ? data.topicPlans : null;
    const importedKoushMessages = Array.isArray(data.koushMessages) ? data.koushMessages : null;

    if (!Array.isArray(importedTasks)) {
      throw new Error("No task list found.");
    }

    tasks = importedTasks.map(normaliseTask).filter(Boolean);
    if (importedTopicPlans) {
      topicPlans = importedTopicPlans.map(normaliseTopicPlan).filter(Boolean);
    }
    if (importedKoushMessages) {
      koushMessages = importedKoushMessages.map(normaliseKoushMessage).filter(Boolean).slice(-20);
    }
    if (data.settings?.dailyLimit) {
      settings = { ...settings, ...data.settings, dailyLimit: Number(data.settings.dailyLimit) };
      elements.dailyLimit.value = settings.dailyLimit;
      elements.plannerMinutes.value = settings.dailyLimit;
      saveSettings();
    }

    saveTasks();
    saveTopicPlans();
    saveKoushMessages();
    render();
    setBackupStatus("Backup imported.");
  } catch (error) {
    setBackupStatus("Could not import that JSON file.");
  } finally {
    event.target.value = "";
  }
});

elements.savedTopicPlans.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-plan-action]");
  if (!button) {
    return;
  }

  const plan = topicPlans.find((item) => item.id === button.dataset.id);
  if (!plan) {
    return;
  }

  if (button.dataset.planAction === "load") {
    settings.activeTopicPlanId = plan.id;
    saveSettings();
    renderSmartPlanner();
  }

  if (button.dataset.planAction === "edit") {
    fillPlannerForm(plan);
  }

  if (button.dataset.planAction === "delete") {
    topicPlans = topicPlans.filter((item) => item.id !== plan.id);
    if (settings.activeTopicPlanId === plan.id) {
      settings.activeTopicPlanId = topicPlans[0]?.id || "";
      saveSettings();
    }
    saveTopicPlans();
    render();
  }
});

elements.taskList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) {
    return;
  }

  const task = tasks.find((item) => item.id === button.dataset.id);
  if (!task) {
    return;
  }

  if (button.dataset.action === "edit") {
    editTask(task);
  }

  if (button.dataset.action === "delete") {
    tasks = tasks.filter((item) => item.id !== task.id);
    saveTasks();
    render();
  }
});

elements.taskList.addEventListener("change", (event) => {
  const checkbox = event.target.closest("input[type='checkbox'][data-id]");
  if (!checkbox) {
    return;
  }

  tasks = tasks.map((task) => task.id === checkbox.dataset.id ? { ...task, complete: checkbox.checked } : task);
  saveTasks();
  render();
});

function loadTasks() {
  const stored = localStorage.getItem(storageKey);
  if (!stored) {
    return [];
  }

  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed.map(normaliseTask).filter(Boolean) : [];
  } catch (error) {
    return [];
  }
}

function loadSettings() {
  try {
    return { dailyLimit: 180, activeTopicPlanId: "", ...JSON.parse(localStorage.getItem(settingsKey)) };
  } catch (error) {
    return { dailyLimit: 180, activeTopicPlanId: "" };
  }
}

function loadTopicPlans() {
  const stored = localStorage.getItem(topicPlansKey);
  if (!stored) {
    return [];
  }

  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed.map(normaliseTopicPlan).filter(Boolean) : [];
  } catch (error) {
    return [];
  }
}

function loadKoushMessages() {
  const stored = localStorage.getItem(koushChatKey);
  if (!stored) {
    return [];
  }

  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed.map(normaliseKoushMessage).filter(Boolean).slice(-20) : [];
  } catch (error) {
    return [];
  }
}

function saveTasks() {
  localStorage.setItem(storageKey, JSON.stringify(tasks));
}

function saveKoushMessages() {
  localStorage.setItem(koushChatKey, JSON.stringify(koushMessages.slice(-20)));
}

function saveTopicPlans() {
  localStorage.setItem(topicPlansKey, JSON.stringify(topicPlans));
}

function saveSettings() {
  localStorage.setItem(settingsKey, JSON.stringify(settings));
}

function render() {
  renderDashboard();
  renderSubjectControls();
  renderSmartPlanner();
  renderKoushChat();
  renderTodayPlan();
  renderTasks();
}

function renderDashboard() {
  const incomplete = tasks.filter((task) => !task.complete);
  const completed = tasks.length - incomplete.length;
  const dueThisWeek = incomplete.filter((task) => {
    const days = daysUntil(task.deadline);
    return days >= 0 && days <= 7;
  }).length;
  const minutesRemaining = incomplete.reduce((sum, task) => sum + Number(task.estimatedTime || 0), 0);

  elements.statIncomplete.textContent = incomplete.length;
  elements.statWeek.textContent = dueThisWeek;
  elements.statTime.textContent = formatMinutes(minutesRemaining);
  elements.statCompleted.textContent = completed;
}

function renderSubjectControls() {
  const taskSubjects = tasks.map((task) => task.subject).filter(Boolean);
  const planSubjects = topicPlans.map((plan) => plan.subject).filter(Boolean);
  const subjects = [...new Set([...taskSubjects, ...planSubjects])]
    .sort((a, b) => a.localeCompare(b));
  const currentFilter = elements.subjectFilter.value;

  elements.subjectFilter.innerHTML = `<option value="all">All subjects</option>${subjects
    .map((subject) => `<option value="${escapeAttribute(subject)}">${escapeHtml(subject)}</option>`)
    .join("")}`;

  if (subjects.includes(currentFilter)) {
    elements.subjectFilter.value = currentFilter;
  }

  elements.subjectOptions.innerHTML = subjects
    .map((subject) => `<option value="${escapeAttribute(subject)}"></option>`)
    .join("");
}

function renderSmartPlanner() {
  renderActiveTopicPlan();
  renderSavedTopicPlans();
}

function renderActiveTopicPlan() {
  const activePlan = topicPlans.find((plan) => plan.id === settings.activeTopicPlanId) || topicPlans[0];

  if (!activePlan) {
    elements.smartPlanSummary.textContent = "Add topics to generate a study plan.";
    elements.smartPlan.innerHTML = `<div class="empty-state">Enter your topics and generate a daily plan.</div>`;
    return;
  }

  const studyPlan = activePlan.aiPlan
    ? normaliseStudyPlanOutput(activePlan.aiPlan, activePlan)
    : buildTopicStudyPlan(activePlan);
  const sourceBadge = activePlan.aiPlan ? "AI generated" : "Quick rules";
  elements.smartPlanSummary.textContent = `${studyPlan.blocks.length} blocks for ${formatMinutes(studyPlan.totalMinutes)}.`;

  const focusItems = studyPlan.focusPoints
    .map((point) => `<li>${escapeHtml(point)}</li>`)
    .join("");
  const blockItems = studyPlan.blocks.map((block, index) => `
    <article class="study-block">
      <div class="block-topline">
        <span class="block-number">${index + 1}</span>
        <h3 class="block-title">${escapeHtml(block.title)}</h3>
        <span class="badge">${block.minutes} min</span>
      </div>
      <p class="block-meta">${escapeHtml(block.mode)} - ${escapeHtml(block.topic)}</p>
      <ul class="block-actions">
        ${block.actions.map((action) => `<li>${escapeHtml(action)}</li>`).join("")}
      </ul>
    </article>
  `).join("");
  const questionCards = studyPlan.questions.map((topic) => `
    <article class="topic-question-card">
      <h4>${escapeHtml(topic.topic)}</h4>
      <ol class="question-list">
        ${topic.questions.map((question) => `<li>${escapeHtml(question)}</li>`).join("")}
      </ol>
    </article>
  `).join("");

  elements.smartPlan.innerHTML = `
    <div class="smart-summary">
      <div class="mini-stat">
        <span>Subject</span>
        <strong>${escapeHtml(activePlan.subject)}</strong>
      </div>
      <div class="mini-stat">
        <span>Goal date</span>
        <strong>${escapeHtml(formatDeadline(activePlan.deadline))}</strong>
      </div>
      <div class="mini-stat">
        <span>Topics today</span>
        <strong>${studyPlan.selectedTopics.length}</strong>
      </div>
    </div>
    <article class="study-block">
      <div class="block-topline">
        <h3 class="block-title">What to study</h3>
        <span class="subject-pill">${escapeHtml(activePlan.name)}</span>
        <span class="badge ${activePlan.aiPlan ? "green" : ""}">${sourceBadge}</span>
      </div>
      ${studyPlan.summary ? `<p class="task-notes">${escapeHtml(studyPlan.summary)}</p>` : ""}
      <ul class="focus-list">${focusItems}</ul>
    </article>
    ${blockItems}
    <div class="question-grid">${questionCards}</div>
  `;
}

function renderSavedTopicPlans() {
  if (!topicPlans.length) {
    elements.savedTopicPlans.innerHTML = "";
    return;
  }

  elements.savedTopicPlans.innerHTML = topicPlans.map((plan) => {
    const isActive = plan.id === (settings.activeTopicPlanId || topicPlans[0]?.id);
    return `
      <article class="saved-plan-card">
        <div>
          <div class="task-topline">
            <h3>${escapeHtml(plan.name)}</h3>
            <span class="subject-pill">${escapeHtml(plan.subject)}</span>
            ${isActive ? `<span class="badge green">Showing</span>` : ""}
          </div>
          <p class="task-meta">
            <span>${escapeHtml(formatDeadline(plan.deadline))}</span>
            <span>${formatMinutes(plan.minutes)}</span>
            <span>${plan.topics.length} topic${plan.topics.length === 1 ? "" : "s"}</span>
            <span>Confidence ${plan.confidence}/5</span>
            ${plan.aiPlan ? "<span>AI plan saved</span>" : ""}
          </p>
        </div>
        <div class="saved-plan-actions">
          <button class="secondary" type="button" data-plan-action="load" data-id="${plan.id}">Show</button>
          <button class="secondary" type="button" data-plan-action="edit" data-id="${plan.id}">Edit</button>
          <button class="danger" type="button" data-plan-action="delete" data-id="${plan.id}">Delete</button>
        </div>
      </article>
    `;
  }).join("");
}

function renderTodayPlan() {
  const limit = Number(settings.dailyLimit) || 180;
  const plan = buildTodayPlan(limit);
  const total = plan.reduce((sum, task) => sum + task.plannedMinutes, 0);

  elements.planSummary.textContent = plan.length
    ? `${formatMinutes(total)} planned from a ${formatMinutes(limit)} limit.`
    : "No incomplete tasks fit your current study limit.";

  if (!plan.length) {
    elements.todayPlan.innerHTML = `<div class="empty-state">Add a task or increase your daily limit to build today's plan.</div>`;
    return;
  }

  elements.todayPlan.innerHTML = plan.map((task, index) => {
    const warnings = getWarnings(task)
      .map((warning) => `<span class="badge ${warning.tone}">${warning.label}</span>`)
      .join("");

    return `
      <article class="plan-item">
        <div class="plan-topline">
          <span class="plan-rank">${index + 1}</span>
          <h3 class="plan-title">${escapeHtml(task.name)}</h3>
          <span class="subject-pill">${escapeHtml(task.subject)}</span>
        </div>
        <p class="plan-meta">
          <span>${formatDeadline(task.deadline)}</span>
          <span>${task.plannedMinutes} min today</span>
          <span>Difficulty ${task.difficulty}/5</span>
          <span>${task.priority} priority</span>
        </p>
        ${warnings ? `<div class="warning-row">${warnings}</div>` : ""}
      </article>
    `;
  }).join("");
}

function renderTasks() {
  const subject = elements.subjectFilter.value;
  const sortBy = elements.sortBy.value;
  const visibleTasks = tasks
    .filter((task) => subject === "all" || task.subject === subject)
    .sort((a, b) => compareTasks(a, b, sortBy));

  if (!visibleTasks.length) {
    elements.taskList.innerHTML = `<div class="empty-state">No tasks match this view.</div>`;
    return;
  }

  elements.taskList.innerHTML = visibleTasks.map((task) => {
    const warnings = getWarnings(task)
      .map((warning) => `<span class="badge ${warning.tone}">${warning.label}</span>`)
      .join("");

    return `
      <article class="task-card ${task.complete ? "completed" : ""}">
        <div class="task-main">
          <div class="task-topline">
            <h3 class="task-title">${escapeHtml(task.name)}</h3>
            <span class="subject-pill">${escapeHtml(task.subject)}</span>
            ${task.complete ? `<span class="badge green">Complete</span>` : ""}
          </div>
          <p class="task-meta">
            <span>${formatDeadline(task.deadline)}</span>
            <span>${task.estimatedTime} min</span>
            <span>Difficulty ${task.difficulty}/5</span>
            <span>${task.priority} priority</span>
          </p>
          ${task.notes ? `<p class="task-notes">${escapeHtml(task.notes)}</p>` : ""}
          ${warnings ? `<div class="warning-row">${warnings}</div>` : ""}
        </div>
        <div class="task-actions">
          <label class="complete-toggle">
            <input type="checkbox" data-id="${task.id}" ${task.complete ? "checked" : ""}>
            Done
          </label>
          <button class="secondary" type="button" data-action="edit" data-id="${task.id}">Edit</button>
          <button class="danger" type="button" data-action="delete" data-id="${task.id}">Delete</button>
        </div>
      </article>
    `;
  }).join("");
}

function renderKoushChat() {
  if (!koushMessages.length) {
    elements.koushChat.innerHTML = `<div class="empty-state">Ask Koush for help with a topic, a practice question, or what to study next.</div>`;
    return;
  }

  elements.koushChat.innerHTML = koushMessages.map((message) => `
    <article class="koush-message ${message.role === "user" ? "user" : "assistant"}">
      <strong>${message.role === "user" ? "You" : "Koush"}</strong>
      <p>${escapeHtml(message.content)}</p>
    </article>
  `).join("");
  elements.koushChat.scrollTop = elements.koushChat.scrollHeight;
}

function readPlannerForm() {
  const topics = parseTopics(elements.plannerTopics.value);
  const existing = topicPlans.find((plan) => plan.id === elements.plannerId.value);

  if (!topics.length) {
    setAiPlanStatus("Add at least one topic first.");
    return null;
  }

  const plan = {
    id: elements.plannerId.value || crypto.randomUUID(),
    name: elements.plannerName.value.trim(),
    subject: elements.plannerSubject.value.trim(),
    deadline: elements.plannerDeadline.value,
    minutes: Math.max(20, Number(elements.plannerMinutes.value) || settings.dailyLimit),
    confidence: clamp(Number(elements.plannerConfidence.value) || 3, 1, 5),
    focus: elements.plannerFocus.value,
    topics,
    createdAt: existing?.createdAt || new Date().toISOString()
  };

  if (!plan.name || !plan.subject || !plan.deadline) {
    setAiPlanStatus("Fill in the plan name, subject, date, and topics.");
    return null;
  }

  return plan;
}

async function askKoush(event) {
  event.preventDefault();

  const question = elements.koushQuestion.value.trim();
  if (!question) {
    return;
  }

  const userMessage = {
    id: crypto.randomUUID(),
    role: "user",
    content: question,
    createdAt: new Date().toISOString()
  };

  koushMessages = [...koushMessages, userMessage].slice(-20);
  saveKoushMessages();
  renderKoushChat();
  elements.koushQuestion.value = "";
  elements.askKoushButton.disabled = true;
  elements.askKoushButton.textContent = "Thinking...";
  setKoushStatus("Koush is thinking...");

  try {
    const response = await fetch("/.netlify/functions/ask-koush", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        messages: koushMessages.slice(0, -1).slice(-8),
        context: buildKoushContext()
      })
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.error || "Koush request failed.");
    }

    const answer = String(data.answer || "").trim();
    if (!answer) {
      throw new Error("Koush gave an empty answer.");
    }

    koushMessages = [...koushMessages, {
      id: crypto.randomUUID(),
      role: "assistant",
      content: answer,
      createdAt: new Date().toISOString()
    }].slice(-20);
    saveKoushMessages();
    renderKoushChat();
    setKoushStatus("");
  } catch (error) {
    const fallback = buildLocalKoushFallback(question);
    koushMessages = [...koushMessages, {
      id: crypto.randomUUID(),
      role: "assistant",
      content: fallback,
      createdAt: new Date().toISOString()
    }].slice(-20);
    saveKoushMessages();
    renderKoushChat();
    setKoushStatus("Koush needs the deployed Groq function for full AI answers.");
  } finally {
    elements.askKoushButton.disabled = false;
    elements.askKoushButton.textContent = "Ask Koush";
  }
}

function buildKoushContext() {
  const incompleteTasks = tasks
    .filter((task) => !task.complete)
    .sort((a, b) => comparePlanPriority(a, b))
    .slice(0, 8)
    .map((task) => ({
      name: task.name,
      subject: task.subject,
      deadline: task.deadline,
      difficulty: task.difficulty,
      estimatedTime: task.estimatedTime,
      priority: task.priority
    }));
  const activePlan = topicPlans.find((plan) => plan.id === settings.activeTopicPlanId) || topicPlans[0] || null;

  return {
    dailyLimit: settings.dailyLimit,
    incompleteTasks,
    activeTopicPlan: activePlan ? {
      name: activePlan.name,
      subject: activePlan.subject,
      deadline: activePlan.deadline,
      minutes: activePlan.minutes,
      confidence: activePlan.confidence,
      focus: activePlan.focus,
      topics: activePlan.topics
    } : null
  };
}

function buildLocalKoushFallback(question) {
  const activePlan = topicPlans.find((plan) => plan.id === settings.activeTopicPlanId) || topicPlans[0];
  const topicHint = activePlan?.topics?.[0] || "your weakest topic";

  return [
    "I can answer properly once the site is deployed with GROQ_API_KEY.",
    "",
    `For now, try this: spend 10 minutes recalling what you know about ${topicHint}, then write 5 practice questions from your notes.`,
    `Your question was: ${question}`
  ].join("\n");
}

async function generateAiStudyPlan() {
  const plan = readPlannerForm();
  if (!plan) {
    return;
  }

  setAiPlanStatus("Asking AI to build your study plan...");
  elements.generateAiPlan.disabled = true;
  elements.generateAiPlan.textContent = "Generating...";

  try {
    const response = await fetch("/.netlify/functions/ai-plan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan })
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.error || "AI request failed.");
    }

    const aiPlan = normaliseStudyPlanOutput(data.plan, plan);
    const savedPlan = {
      ...plan,
      aiPlan,
      aiGeneratedAt: new Date().toISOString()
    };

    topicPlans = [savedPlan, ...topicPlans.filter((item) => item.id !== savedPlan.id)];
    settings.activeTopicPlanId = savedPlan.id;
    saveTopicPlans();
    saveSettings();
    resetPlannerForm();
    render();
    setAiPlanStatus("AI plan generated and saved.");
  } catch (error) {
    setAiPlanStatus("AI is not connected here yet. Deploy on Netlify and add GROQ_API_KEY to turn it on.");
  } finally {
    elements.generateAiPlan.disabled = false;
    elements.generateAiPlan.textContent = "Generate with AI";
  }
}

function buildTodayPlan(limit) {
  let remaining = limit;
  const plan = [];
  const rankedTasks = tasks
    .filter((task) => !task.complete)
    .sort((a, b) => comparePlanPriority(a, b));

  for (const task of rankedTasks) {
    if (remaining <= 0) {
      break;
    }

    const estimate = Number(task.estimatedTime) || 0;
    if (estimate <= remaining) {
      plan.push({ ...task, plannedMinutes: estimate });
      remaining -= estimate;
    }
  }

  if (!plan.length && rankedTasks.length && remaining >= 15) {
    const firstTask = rankedTasks[0];
    plan.push({ ...firstTask, plannedMinutes: Math.min(remaining, firstTask.estimatedTime) });
  }

  return plan;
}

function buildTopicStudyPlan(plan) {
  const totalMinutes = Math.max(20, Number(plan.minutes) || settings.dailyLimit);
  const rankedTopics = rankTopicsForPlan(plan);
  const selectedTopics = rankedTopics.slice(0, chooseTopicCount(totalMinutes, rankedTopics.length, plan.confidence));
  const reviewMinutes = totalMinutes >= 45 ? roundToFive(Math.min(20, Math.max(5, totalMinutes * 0.12))) : 5;
  const setupMinutes = totalMinutes >= 60 ? 10 : 5;
  const topicMinutes = Math.max(10, totalMinutes - setupMinutes - reviewMinutes);
  const perTopicMinutes = Math.max(10, roundToFive(topicMinutes / Math.max(1, selectedTopics.length)));
  const blocks = [
    {
      title: "Quick recall setup",
      topic: "All topics",
      mode: "Memory check",
      minutes: setupMinutes,
      actions: [
        "Write everything you already remember without notes.",
        "Mark weak areas before opening your textbook or class notes."
      ]
    }
  ];

  selectedTopics.forEach((topic, index) => {
    const mode = chooseStudyMode(plan.focus, plan.confidence, index);
    blocks.push({
      title: `${mode}: ${topic.title}`,
      topic: topic.title,
      mode,
      minutes: perTopicMinutes,
      actions: getTopicActions(plan.subject, topic.title, mode)
    });
  });

  blocks.push({
    title: "Mark, fix, and schedule",
    topic: "All topics",
    mode: "Review",
    minutes: reviewMinutes,
    actions: [
      "Mark your answers and write one mistake rule for each error.",
      "Choose the first topic to revisit tomorrow."
    ]
  });

  return {
    totalMinutes,
    selectedTopics,
    blocks: fitBlocksToLimit(blocks, totalMinutes),
    focusPoints: getFocusPoints(plan, selectedTopics),
    questions: selectedTopics.map((topic) => ({
      topic: topic.title,
      questions: generateQuestions(plan.subject, topic.title, plan.focus)
    }))
  };
}

function normaliseStudyPlanOutput(planData, basePlan) {
  const fallback = buildTopicStudyPlan(basePlan);
  const raw = planData && typeof planData === "object" ? planData : {};
  const selectedTopics = Array.isArray(raw.selectedTopics)
    ? raw.selectedTopics.map(normaliseSelectedTopic).filter(Boolean)
    : fallback.selectedTopics;
  const blocks = Array.isArray(raw.blocks)
    ? raw.blocks.map((block) => normaliseStudyBlock(block)).filter(Boolean)
    : fallback.blocks;
  const questions = Array.isArray(raw.questions)
    ? raw.questions.map((item) => normaliseQuestionSet(item)).filter(Boolean)
    : fallback.questions;
  const focusPoints = Array.isArray(raw.focusPoints)
    ? raw.focusPoints.map((point) => String(point).trim()).filter(Boolean).slice(0, 6)
    : fallback.focusPoints;

  return {
    summary: raw.summary ? String(raw.summary).trim() : "",
    totalMinutes: Math.max(20, Number(raw.totalMinutes) || Number(basePlan.minutes) || fallback.totalMinutes),
    selectedTopics: selectedTopics.length ? selectedTopics : fallback.selectedTopics,
    blocks: blocks.length ? blocks : fallback.blocks,
    focusPoints: focusPoints.length ? focusPoints : fallback.focusPoints,
    questions: questions.length ? questions : fallback.questions
  };
}

function normaliseSelectedTopic(topic) {
  if (typeof topic === "string") {
    return topic.trim() ? { title: topic.trim() } : null;
  }

  if (topic && typeof topic === "object" && topic.title) {
    return { title: String(topic.title).trim() };
  }

  return null;
}

function normaliseStudyBlock(block) {
  if (!block || typeof block !== "object" || !block.title) {
    return null;
  }

  const actions = Array.isArray(block.actions)
    ? block.actions.map((action) => String(action).trim()).filter(Boolean).slice(0, 5)
    : [];

  return {
    title: String(block.title).trim(),
    topic: block.topic ? String(block.topic).trim() : "Study",
    mode: block.mode ? String(block.mode).trim() : "Study",
    minutes: Math.max(5, Number(block.minutes) || 20),
    actions: actions.length ? actions : ["Study the topic, practise questions, then mark your work."]
  };
}

function normaliseQuestionSet(item) {
  if (!item || typeof item !== "object" || !item.topic || !Array.isArray(item.questions)) {
    return null;
  }

  const questions = item.questions
    .map((question) => String(question).trim())
    .filter(Boolean)
    .slice(0, 8);

  if (!questions.length) {
    return null;
  }

  return {
    topic: String(item.topic).trim(),
    questions
  };
}

function fitBlocksToLimit(blocks, totalMinutes) {
  const fitted = blocks.map((block) => ({ ...block }));
  let overflow = fitted.reduce((sum, block) => sum + block.minutes, 0) - totalMinutes;

  for (let index = fitted.length - 2; index > 0 && overflow > 0; index -= 1) {
    const removable = Math.max(0, fitted[index].minutes - 10);
    const reduction = Math.min(removable, overflow);
    fitted[index].minutes -= reduction;
    overflow -= reduction;
  }

  return fitted.filter((block) => block.minutes > 0);
}

function rankTopicsForPlan(plan) {
  const urgency = Math.max(0, 14 - Math.max(0, daysUntil(plan.deadline)));
  const weakScore = 6 - Number(plan.confidence);

  return plan.topics
    .map((topic, index) => ({
      title: topic,
      score: urgency + weakScore * 2 + (plan.focus === "practice" ? 1 : 0) - index * 0.1
    }))
    .sort((a, b) => b.score - a.score || a.title.localeCompare(b.title));
}

function chooseTopicCount(minutes, topicCount, confidence) {
  if (topicCount <= 1) {
    return topicCount;
  }

  let count = 1;
  if (minutes >= 70) {
    count = 2;
  }
  if (minutes >= 120) {
    count = 3;
  }
  if (minutes >= 180) {
    count = 4;
  }
  if (Number(confidence) >= 4 && minutes >= 120) {
    count += 1;
  }

  return Math.min(topicCount, count);
}

function chooseStudyMode(focus, confidence, index) {
  if (focus === "learn") {
    return index === 0 ? "Learn" : "Apply";
  }
  if (focus === "revise") {
    return "Revise";
  }
  if (focus === "practice") {
    return "Practice";
  }
  if (Number(confidence) <= 2 && index === 0) {
    return "Learn";
  }
  return index % 2 === 0 ? "Revise" : "Practice";
}

function getFocusPoints(plan, selectedTopics) {
  const subject = getSubjectFamily(plan.subject);
  const topicText = selectedTopics.map((topic) => topic.title).join(", ");
  const base = [
    `Start with ${topicText || "your weakest topic"}.`,
    "Use active recall before reading notes.",
    "Finish with marked questions and a mistake log."
  ];

  if (subject === "maths") {
    base.splice(1, 0, "Prioritise formulas, worked examples, and exam-style questions.");
  } else if (subject === "english") {
    base.splice(1, 0, "Prioritise thesis, evidence, paragraph structure, and timed writing.");
  } else if (subject === "science") {
    base.splice(1, 0, "Prioritise definitions, diagrams, calculations, and practical errors.");
  } else if (subject === "humanities") {
    base.splice(1, 0, "Prioritise causes, evidence, case studies, and clear explanations.");
  }

  return base.slice(0, 4);
}

function getTopicActions(subject, topic, mode) {
  const family = getSubjectFamily(subject);
  const actionMap = {
    maths: {
      Learn: [`Rewrite the rule or formula for ${topic}.`, "Copy one worked example, then redo it without looking.", "Write the trigger words that tell you to use this method."],
      Revise: [`Summarise the steps for ${topic} from memory.`, "Redo two questions you previously got wrong.", "Check answers and write the exact cause of any error."],
      Practice: [`Complete three exam-style ${topic} questions.`, "Do one question under timed conditions.", "Mark every line of working, not just the final answer."],
      Apply: [`Do one standard and one harder ${topic} question.`, "Explain the method aloud in plain language.", "Add one mistake to your error log."]
    },
    english: {
      Learn: [`Build a quote or evidence bank for ${topic}.`, "Write a one-sentence argument.", "Plan one paragraph before writing."],
      Revise: [`Rewrite your thesis for ${topic}.`, "Choose the strongest evidence and explain why it matters.", "Tighten one paragraph using TEEL or your class structure."],
      Practice: [`Write one timed paragraph on ${topic}.`, "Underline analysis, not just evidence.", "Mark for clarity, relevance, and depth."],
      Apply: [`Connect ${topic} to a likely prompt.`, "Draft a mini essay plan.", "Write the weakest paragraph again better."]
    },
    science: {
      Learn: [`Define the key terms in ${topic}.`, "Draw the process, system, or model from memory.", "Check notes and fix missing labels."],
      Revise: [`Explain ${topic} using because, therefore, and however.`, "Do one calculation or data question if relevant.", "List common practical or measurement errors."],
      Practice: [`Answer four short-answer questions on ${topic}.`, "Include units, labels, and command-term language.", "Mark against your notes or marking guide."],
      Apply: [`Connect ${topic} to an experiment or real example.`, "Explain one cause-and-effect chain.", "Write one exam-style answer and improve it."]
    },
    humanities: {
      Learn: [`List the key facts, people, dates, or terms for ${topic}.`, "Create a cause-and-effect chain.", "Add one strong example or case study."],
      Revise: [`Explain why ${topic} matters in three sentences.`, "Link evidence to the question, not just the content.", "Check for missing detail or vague wording."],
      Practice: [`Write one timed response on ${topic}.`, "Use evidence in every body point.", "Mark for argument, detail, and structure."],
      Apply: [`Compare ${topic} with a related idea.`, "Make a mini plan for a possible exam question.", "Write a stronger final sentence."]
    },
    general: {
      Learn: [`Define the key ideas in ${topic}.`, "Make a one-page summary.", "Teach the idea aloud without notes."],
      Revise: [`Do a closed-book recall of ${topic}.`, "Fill gaps using your notes.", "Turn mistakes into flashcards."],
      Practice: [`Answer five questions on ${topic}.`, "Check answers and write corrections.", "Repeat the hardest question."],
      Apply: [`Use ${topic} in a new example.`, "Explain how it connects to another topic.", "Write one exam-style answer."]
    }
  };

  return (actionMap[family] || actionMap.general)[mode] || actionMap[family]?.Revise || actionMap.general.Revise;
}

function generateQuestions(subject, topic, focus) {
  const family = getSubjectFamily(subject);
  const templates = {
    maths: [
      `What formula, rule, or method controls ${topic}?`,
      `Solve one easy, one medium, and one hard question on ${topic}.`,
      `Where could you lose marks in a ${topic} question?`,
      `Explain each step of a ${topic} solution without using notes.`,
      `Create a harder ${topic} question and write the full solution.`
    ],
    english: [
      `What is your strongest argument about ${topic}?`,
      `Which three pieces of evidence best support ${topic}?`,
      `Write one timed paragraph connected to ${topic}.`,
      `How does ${topic} link to a broader theme or author purpose?`,
      `What would a top-band sentence about ${topic} sound like?`
    ],
    science: [
      `Define the key terms needed for ${topic}.`,
      `Draw or describe the process behind ${topic}.`,
      `What is the cause-and-effect explanation for ${topic}?`,
      `Answer one data, calculation, or graph question linked to ${topic}.`,
      `What practical errors or limitations could appear in ${topic}?`
    ],
    humanities: [
      `What are the key facts or events for ${topic}?`,
      `What caused ${topic}, and what changed because of it?`,
      `Which evidence or case study best proves your point about ${topic}?`,
      `Write a short response using ${topic} in an argument.`,
      `What comparison or counterpoint makes ${topic} more sophisticated?`
    ],
    general: [
      `Explain ${topic} in under three minutes without notes.`,
      `List the key terms, rules, or examples for ${topic}.`,
      `Write five quick questions that would test ${topic}.`,
      `What is the most common mistake in ${topic}?`,
      `Do one exam-style answer or problem for ${topic}.`
    ]
  };

  const questions = templates[family] || templates.general;
  if (focus === "practice") {
    return [questions[1], questions[4], questions[2], questions[3], questions[0]];
  }
  if (focus === "learn") {
    return [questions[0], questions[2], questions[3], questions[1], questions[4]];
  }
  return questions;
}

function getSubjectFamily(subject) {
  const value = subject.toLowerCase();
  if (value.includes("math")) {
    return "maths";
  }
  if (value.includes("english") || value.includes("literature")) {
    return "english";
  }
  if (value.includes("bio") || value.includes("chem") || value.includes("physics") || value.includes("science")) {
    return "science";
  }
  if (value.includes("history") || value.includes("legal") || value.includes("geo") || value.includes("economics") || value.includes("business")) {
    return "humanities";
  }
  return "general";
}

function comparePlanPriority(a, b) {
  const daysA = Math.max(daysUntil(a.deadline), -30);
  const daysB = Math.max(daysUntil(b.deadline), -30);

  return daysA - daysB
    || priorityWeight[b.priority] - priorityWeight[a.priority]
    || b.difficulty - a.difficulty
    || a.estimatedTime - b.estimatedTime
    || a.name.localeCompare(b.name);
}

function compareTasks(a, b, sortBy) {
  if (a.complete !== b.complete) {
    return Number(a.complete) - Number(b.complete);
  }

  if (sortBy === "deadline") {
    return parseDate(a.deadline) - parseDate(b.deadline);
  }

  if (sortBy === "difficulty") {
    return b.difficulty - a.difficulty || parseDate(a.deadline) - parseDate(b.deadline);
  }

  if (sortBy === "priority") {
    return priorityWeight[b.priority] - priorityWeight[a.priority] || parseDate(a.deadline) - parseDate(b.deadline);
  }

  if (sortBy === "estimatedTime") {
    return b.estimatedTime - a.estimatedTime || parseDate(a.deadline) - parseDate(b.deadline);
  }

  return 0;
}

function editTask(task) {
  elements.taskId.value = task.id;
  elements.taskName.value = task.name;
  elements.subject.value = task.subject;
  elements.deadline.value = task.deadline;
  elements.difficulty.value = task.difficulty;
  elements.estimatedTime.value = task.estimatedTime;
  elements.priority.value = task.priority;
  elements.notes.value = task.notes || "";
  elements.formTitle.textContent = "Edit Task";
  elements.submitTask.textContent = "Save task";
  elements.cancelEdit.classList.remove("hidden");
  elements.taskName.focus();
}

function resetForm() {
  elements.taskForm.reset();
  elements.taskId.value = "";
  elements.difficulty.value = "3";
  elements.estimatedTime.value = "60";
  elements.priority.value = "Medium";
  elements.formTitle.textContent = "New Task";
  elements.submitTask.textContent = "Add task";
  elements.cancelEdit.classList.add("hidden");
}

function fillPlannerForm(plan) {
  elements.plannerId.value = plan.id;
  elements.plannerName.value = plan.name;
  elements.plannerSubject.value = plan.subject;
  elements.plannerDeadline.value = plan.deadline;
  elements.plannerMinutes.value = plan.minutes;
  elements.plannerConfidence.value = plan.confidence;
  elements.plannerFocus.value = plan.focus;
  elements.plannerTopics.value = plan.topics.join("\n");
  elements.generatePlan.textContent = "Update plan";
  elements.aiPlanStatus.textContent = plan.aiPlan
    ? "Editing this will replace the saved AI version if you generate with AI again."
    : "";
  elements.plannerName.focus();
}

function resetPlannerForm() {
  elements.topicPlannerForm.reset();
  elements.plannerId.value = "";
  elements.plannerMinutes.value = settings.dailyLimit;
  elements.plannerConfidence.value = "3";
  elements.plannerFocus.value = "mixed";
  elements.generatePlan.textContent = "Generate quick plan";
}

function getWarnings(task) {
  if (task.complete) {
    return [];
  }

  const days = daysUntil(task.deadline);
  const warnings = [];

  if (days < 0) {
    warnings.push({ label: "Overdue", tone: "red" });
  } else if (days === 0) {
    warnings.push({ label: "Due today", tone: "red" });
  } else if (days === 1) {
    warnings.push({ label: "Due tomorrow", tone: "amber" });
  }

  if (Number(task.difficulty) >= 4) {
    warnings.push({ label: "High difficulty", tone: "amber" });
  }

  if (task.priority === "High") {
    warnings.push({ label: "High priority", tone: "red" });
  }

  return warnings;
}

function formatDeadline(deadline) {
  const days = daysUntil(deadline);
  if (days < 0) {
    return `${Math.abs(days)} day${Math.abs(days) === 1 ? "" : "s"} overdue`;
  }
  if (days === 0) {
    return "Due today";
  }
  if (days === 1) {
    return "Due tomorrow";
  }
  return `Due in ${days} days`;
}

function daysUntil(deadline) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = parseDate(deadline);
  due.setHours(0, 0, 0, 0);
  return Math.round((due - today) / 86400000);
}

function parseDate(value) {
  return new Date(`${value}T00:00:00`);
}

function formatMinutes(minutes) {
  const safeMinutes = Number(minutes) || 0;
  const hours = Math.floor(safeMinutes / 60);
  const mins = safeMinutes % 60;

  if (!hours) {
    return `${mins}m`;
  }

  if (!mins) {
    return `${hours}h`;
  }

  return `${hours}h ${mins}m`;
}

function parseTopics(value) {
  return [...new Set(String(value)
    .split(/\n|,/)
    .map((topic) => topic.trim())
    .filter(Boolean))]
    .slice(0, 20);
}

function roundToFive(value) {
  return Math.max(5, Math.round(value / 5) * 5);
}

function normaliseTask(task) {
  if (!task || !task.name || !task.subject || !task.deadline) {
    return null;
  }

  return {
    id: task.id || crypto.randomUUID(),
    name: String(task.name),
    subject: String(task.subject),
    deadline: String(task.deadline),
    difficulty: clamp(Number(task.difficulty) || 3, 1, 5),
    estimatedTime: Math.max(5, Number(task.estimatedTime) || 60),
    priority: priorityWeight[task.priority] ? task.priority : "Medium",
    notes: task.notes ? String(task.notes) : "",
    complete: Boolean(task.complete),
    createdAt: task.createdAt || new Date().toISOString()
  };
}

function normaliseTopicPlan(plan) {
  if (!plan || !plan.name || !plan.subject || !plan.deadline || !Array.isArray(plan.topics)) {
    return null;
  }

  return {
    id: plan.id || crypto.randomUUID(),
    name: String(plan.name),
    subject: String(plan.subject),
    deadline: String(plan.deadline),
    minutes: Math.max(20, Number(plan.minutes) || 120),
    confidence: clamp(Number(plan.confidence) || 3, 1, 5),
    focus: ["mixed", "learn", "revise", "practice"].includes(plan.focus) ? plan.focus : "mixed",
    topics: plan.topics.map((topic) => String(topic).trim()).filter(Boolean).slice(0, 20),
    aiPlan: plan.aiPlan ? normaliseStudyPlanOutput(plan.aiPlan, plan) : null,
    aiGeneratedAt: plan.aiGeneratedAt || "",
    createdAt: plan.createdAt || new Date().toISOString()
  };
}

function normaliseKoushMessage(message) {
  if (!message || !["user", "assistant"].includes(message.role) || !message.content) {
    return null;
  }

  return {
    id: message.id || crypto.randomUUID(),
    role: message.role,
    content: String(message.content),
    createdAt: message.createdAt || new Date().toISOString()
  };
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}

function setBackupStatus(message) {
  elements.backupStatus.textContent = message;
  window.setTimeout(() => {
    if (elements.backupStatus.textContent === message) {
      elements.backupStatus.textContent = "";
    }
  }, 3500);
}

function setAiPlanStatus(message) {
  elements.aiPlanStatus.textContent = message;
}

function setKoushStatus(message) {
  elements.koushStatus.textContent = message;
}
